console.log("page loaded...");




function over(element){
    element.muted=true;
    element.play();
}

function out(element){
    element.pause();
}

